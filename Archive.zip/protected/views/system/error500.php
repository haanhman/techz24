<?php
require_once 'exception.php';die;
?>