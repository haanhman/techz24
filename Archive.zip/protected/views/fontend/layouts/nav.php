<nav id="navigation" itemtype="http://schema.org/SiteNavigationElement" itemscope="itemscope" role="navigation"
     class="dd-effect-slide ">
    <div class="navigation-inner">
        <div class="inner">

            <?php $this->renderPartial('//layouts/nav/desktop') ?>
            <?php $this->renderPartial('//layouts/nav/mobile') ?>
            <?php $this->renderPartial('//layouts/nav/search') ?>

        </div>
    </div>
    <!--nav inner-->
</nav>