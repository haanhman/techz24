<div class="banner8">
    <a target="_blank" href="http://ouo.io/ref/XiEqR34B" title="Techz24 - Make short links and earn the biggest money"><img src="<?php echo base_url() ?>/public/assets/fontend/img/ouo_ads.jpg" alt="Techz24 - Make short links and earn the biggest money"></a>
</div>