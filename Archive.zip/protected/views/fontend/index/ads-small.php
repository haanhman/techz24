<div class="widget momizat-ads">
    <div class="widget-head"><h3 class="widget-title"><span>Advertising</span></h3>
    </div>
    <div class="mom-e3lanat-wrap  ">
        <div class="mom-e3lanat " style="margin-bottom:-10px;">
            <div class="mom-e3lanat-inner">

                <div style="margin-bottom:10px;">
                    <a href="https://itunes.apple.com/us/app/id930331514" target="_blank" rel="nofollow">
                        <img title="Monkey Junior: a homeschool curriculum, how to teach your child to read English, French" alt="Monkey Junior: a homeschool curriculum, how to teach your child to read English, French" src="/public/images/ads/monkey_app.png" />
                    </a>
                </div>
                <div>
                    <a href="https://itunes.apple.com/us/app/id979797319" target="_blank" rel="nofollow">
                        <img title="Free english vocabulary quiz" alt="Free english vocabulary quiz" src="/public/images/ads/quiz_app.png" />
                    </a>
                </div>
            </div>
        </div>
        <!--Mom ads-->
    </div>
</div>