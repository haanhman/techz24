<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CategoryWidget
 *
 * @author anhmantk
 */
class VideoWidget extends MyWidget {

    public function run() {
        $this->render('video');
    }

}

