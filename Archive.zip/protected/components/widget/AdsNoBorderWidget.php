<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CategoryWidget
 *
 * @author anhmantk
 */
class AdsNoBorderWidget extends MyWidget {

    public function run() {
        $this->render('ads2');
    }

}

