<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CategoryWidget
 *
 * @author anhmantk
 */
class SocialWidget extends MyWidget {

    public function run() {
        $this->render('social');
    }
}

