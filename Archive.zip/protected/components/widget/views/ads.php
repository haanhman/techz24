<div class="widget">
    <h3 class="blocktitle">Ads</h3>
    <div style="text-align: center">
        <a target="_blank" href="http://ouo.io/ref/XiEqR34B" title="Techz24 - Make short links and earn the biggest money"><img src="<?php echo base_url() ?>/public/assets/fontend/img/ouo_ads_2.jpg" alt="Techz24 - Make short links and earn the biggest money"></a>
    </div>
</div>