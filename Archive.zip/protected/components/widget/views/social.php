<div class="widget momizat-social-icons">
    <div class="widget-head"><h3 class="widget-title"><span>Follow Us</span></h3></div>

    <script>(function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s); js.id = id;
            js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4&appId=1638273013053132";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>
    <script src="https://apis.google.com/js/platform.js" async defer></script>

    <div style="text-align: center">
        <div id="fb-root"></div>
        <div class="fb-page" data-width="265" data-href="https://www.facebook.com/techz24dotcom" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" data-show-posts="false"><div class="fb-xfbml-parse-ignore"></div></div>


        <div style="margin-top: 10px;">
            <div data-layout="portrait" data-width="265" class="g-person" data-href="https://plus.google.com/118045223438632929013"></div>
        </div>
    </div>

</div>
