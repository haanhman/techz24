<div class="widget recentvid">
    <h3 class="blocktitle">RECENT VIDEOS <span><a href="#">MORE</a></span></h3>

    <div class="getvid">
        <div class="flex-video widescreen">
            <iframe height="200" src="http://www.youtube.com/embed/NB_FaOnPtE4"
                    allowfullscreen></iframe>
        </div>
    </div>
</div>