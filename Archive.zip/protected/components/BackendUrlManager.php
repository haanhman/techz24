<?php

class BackendUrlManager extends CUrlManager {

//    public function createUrl($route, $params = array(), $ampersand = '&') {
//        if ($route == 'product/detail') {
//            if (isset($params['id']) && is_numeric($params['id'])) {
//                $params['id'] = hexID($params['id']);
//            }
//        }
//        return parent::createUrl($route, $params, $ampersand);
//    }
}